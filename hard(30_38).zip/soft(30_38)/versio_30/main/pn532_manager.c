#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <esp_log.h>
#include <esp_log_internal.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "sdkconfig.h"
#include "pn532.h"


#define PN532_SCK 18U
#define PN532_MOSI 23U
#define PN532_SS 5U
#define PN532_MISO 19U

static const char *TAG = "APP";
static pn532_t nfc;

void pn532_init(void) {
	pn532_spi_init(&nfc, PN532_SCK, PN532_MISO, PN532_MOSI, PN532_SS);
	pn532_begin(&nfc);

	uint32_t versiondata = pn532_getFirmwareVersion(&nfc);
	if (!versiondata)
	{
		ESP_LOGI(TAG, "Didn't find PN53x board");
		while (1)
		{
			vTaskDelay(1000 / portTICK_RATE_MS);
		}
	}
	// Got ok data, print it out!
	ESP_LOGI(TAG, "Found chip PN5 %x", (versiondata >> 24) & 0xFF);
	ESP_LOGI(TAG, "Firmware ver. %d.%d", (versiondata >> 16) & 0xFF, (versiondata >> 8) & 0xFF);

	// configure board to read RFID tags
	pn532_SAMConfig(&nfc);
}

// Length of the UID (4 or 7 bytes depending on ISO14443A card type)
//return length of uid read if error return -1
//si el timeout es 0 es queda bloquejat
int8_t nfc_task(uint8_t* uid, uint16_t timeout)
{
	int8_t ret;
	uint8_t success;
	uint8_t uid_length;  // Length of the UID (4 or 7 bytes depending on ISO14443A card type)

    ESP_LOGI(TAG, "Waiting for an ISO14443A Card ...");

	// Wait for an ISO14443A type cards (Mifare, etc.).  When one is found
	// 'uid' will be populated with the UID, and uidLength will indicate
	// if the uid is 4 bytes (Mifare Classic) or 7 bytes (Mifare Ultralight)

	success = pn532_readPassiveTargetID(&nfc, PN532_MIFARE_ISO14443A, uid, &uid_length, timeout);

	if (success)
	{
		ret = (int)uid_length;
	}
	else
	{
		// PN532 probably timed out waiting for a card
		ESP_LOGI(TAG, "Timed out waiting for a card");
		ret = -1;
	}

	return ret;
}






