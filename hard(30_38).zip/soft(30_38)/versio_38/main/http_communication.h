/*
 * http_communication.h
 *
 *  Created on: 10 abr 2022
 *      Author: ferranbofill
 */

#ifndef MAIN_HTTP_COMMUNICATION_H_
#define MAIN_HTTP_COMMUNICATION_H_

/* Constants to configure */
#define EXAMPLE_ESP_WIFI_SSID      "Galaxy A30s3F3D"
#define EXAMPLE_ESP_WIFI_PASS      "ucye5103"
#define EXAMPLE_ESP_MAXIMUM_RETRY  5U

#define WEB_SERVER "192.168.43.133"
#define WEB_PORT "5000"
#define TEST_POST "/reserva-maquina"
//---------------------------------

void wifi_init_sta(void);
bool http_request(const char *request, char *answer);


#endif /* MAIN_HTTP_COMMUNICATION_H_ */
