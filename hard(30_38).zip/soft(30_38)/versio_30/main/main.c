#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/gpio.h"


#include "stdbool.h"
#include "math.h"

#include "http_communication.h"
#include "pn532_manager.h"
#include "ssd1306_manager.h"

#define BUZZER_GPIO 17
#define RELE_GPIO 16
#define BLINK_GPIO 2U
#define BYTES_PER_LINE 16U

static const char *TAG = "main";

static uint8_t uidMaster[] = {0xf3, 0x85, 0x13, 0x0c, 0x00, 0x00, 0x00};

static const char *testPostRequest = "POST " TEST_POST " HTTP/1.0\r\n"
    "Host: "WEB_SERVER":"WEB_PORT"\r\n"
    "User-Agent: esp-idf/1.0 esp32\r\n"
	"Content-Type: text/plain\r\n" //entity header
	"Content-Length: 13\r\n" //entity header
	"\r\n";

static struct {
	uint64_t service_time;
	bool service_on;
} serviceParameters;


void uint2HexString(void *buffer, uint16_t buff_len, char* hex)
{
    if (buff_len == 0) {
        return;
    }
    char temp_buffer[BYTES_PER_LINE + 3]; //for not-byte-accessible memory
    const char *ptr_line;
    char *ptr_hd;
    int bytes_cur_line;

    do {
        if (buff_len > BYTES_PER_LINE) {
            bytes_cur_line = BYTES_PER_LINE;
        } else {
            bytes_cur_line = buff_len;
        }
        if (!esp_ptr_byte_accessible(buffer)) {
            //use memcpy to get around alignment issue
            memcpy(temp_buffer, buffer, (bytes_cur_line + 3) / 4 * 4);
            ptr_line = temp_buffer;
        } else {
            ptr_line = buffer;
        }
        ptr_hd = hex;

        ptr_hd += sprintf(ptr_hd, "%p ", buffer);
        for (int i = 0; i < BYTES_PER_LINE; i ++) {
            if ((i & 7) == 0) {
                ptr_hd += sprintf(ptr_hd, " ");
            }
            if (i < bytes_cur_line) {
                ptr_hd += sprintf(ptr_hd, " %02x", ptr_line[i]);
            } else {
                ptr_hd += sprintf(ptr_hd, "   ");
            }
        }
        ptr_hd += sprintf(ptr_hd, "  |");
        for (int i = 0; i < bytes_cur_line; i ++) {
            if (isprint((int)ptr_line[i])) {
                ptr_hd += sprintf(ptr_hd, "%c", ptr_line[i]);
            } else {
                ptr_hd += sprintf(ptr_hd, ".");
            }
        }
        ptr_hd += sprintf(ptr_hd, "|");

        buffer += bytes_cur_line;
        buff_len -= bytes_cur_line;
    } while (buff_len);
}

uint64_t string2uint(char* string, uint8_t length) {
	uint64_t result;
	uint8_t index;

	result = 0;

	for (index = 0; index < length; index++) {
		result += ((uint64_t)string[index] - 48U) * pow(10,(length - index - 1));
	}

	return result;
}

bool checkBuffEqual(uint8_t* buff1, uint8_t* buff2, uint8_t length) {
	bool equal;
	uint8_t index;

	equal = true;
	index = 0;

	while (equal && (index < length)) {

		if (buff1[index] != buff2[index]) {
			equal = false;
		}

		index++;
	}

	return equal;
}

void clearBuff(uint8_t* buff) {

	for (uint8_t i = 0; i < sizeof(buff); i++) {
		buff[i] = 0;
	}

}

void blink_task(void *pvParameter)
{
    gpio_pad_select_gpio(BLINK_GPIO);
    gpio_set_direction(BLINK_GPIO, GPIO_MODE_OUTPUT);
    while (1)
    {
        gpio_set_level(BLINK_GPIO, 0);
        vTaskDelay(900 / portTICK_PERIOD_MS);
        gpio_set_level(BLINK_GPIO, 1);
        vTaskDelay(100 / portTICK_PERIOD_MS);

        if (serviceParameters.service_on && (serviceParameters.service_time != 0)) {
        	serviceParameters.service_time--;
        }

        if ((serviceParameters.service_time == 60) || (serviceParameters.service_time == 50) || (serviceParameters.service_time == 40) ||
			(serviceParameters.service_time == 30) || (serviceParameters.service_time == 20) || (serviceParameters.service_time == 10)) {
			gpio_set_level(BUZZER_GPIO, 1U);
		}
        else if ((serviceParameters.service_time == 59) || (serviceParameters.service_time == 49) || (serviceParameters.service_time == 39) ||
			(serviceParameters.service_time == 29) || (serviceParameters.service_time == 19) || (serviceParameters.service_time == 9))  {
			gpio_set_level(BUZZER_GPIO, 0U);
		}

    }

}

void main_task(void *pvParameter) {
	SSD1306_t dev;
	int8_t uid_length;
	uint8_t uid[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	uint8_t uid_active[MAX_UID_LENGTH];
	char strHex[100];
	char request[500];
	char answer[20];
	uint8_t request_str_index;

	//static parameters init
	serviceParameters.service_on = false;
	serviceParameters.service_time = 0;

	//wifi init
	esp_err_t ret = nvs_flash_init();

	if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
	  ESP_ERROR_CHECK(nvs_flash_erase());
	  ret = nvs_flash_init();
	}

	ESP_ERROR_CHECK(ret);
	ESP_ERROR_CHECK(esp_netif_init());
	ESP_LOGI(TAG, "ESP_WIFI_MODE_STA");
	wifi_init_sta();

	//GPIO init
	gpio_reset_pin(BUZZER_GPIO);
	gpio_reset_pin(RELE_GPIO);
	gpio_set_direction(BUZZER_GPIO, GPIO_MODE_OUTPUT);
	gpio_set_direction(RELE_GPIO, GPIO_MODE_OUTPUT);

	//ssd1306
	i2c_master_init(&dev, CONFIG_SDA_GPIO, CONFIG_SCL_GPIO, CONFIG_RESET_GPIO);
	ssd1306_init(&dev, 128, 64);
	ssd1306_clear_screen(&dev, false);
	ssd1306_contrast(&dev, 0xff);

	//pn532
	pn532_init();

	while(1) {
		ssd1306_clear_screen(&dev, false);
		ssd1306_contrast(&dev, 0xff);
		ssd1306_display_text(&dev, 2, "      OFF", 9, false);

		clearBuff(uid);
		uid_length = nfc_task(uid, 0);

		if (uid_length != -1) {
			gpio_set_level(BUZZER_GPIO, 1U);
			vTaskDelay(1000 / portTICK_RATE_MS);
			gpio_set_level(BUZZER_GPIO, 0U);
			vTaskDelay(1000 / portTICK_RATE_MS);

			uint2HexString(uid, uid_length, strHex);

			if (checkBuffEqual(uid, uidMaster, MAX_UID_LENGTH)) {
				serviceParameters.service_time = 0;
				serviceParameters.service_on = true;
				gpio_set_level(RELE_GPIO, 1U);
				ssd1306_clear_screen(&dev, true);
				ssd1306_contrast(&dev, 0xff);
				ssd1306_display_text(&dev, 2, "   MANUAL MODE", 14, true);

				while (serviceParameters.service_on) {
					uid_length = nfc_task(uid, 5000);

					if (uid_length != -1) {
						gpio_set_level(BUZZER_GPIO, 1U);
						vTaskDelay(1000 / portTICK_RATE_MS);
						gpio_set_level(BUZZER_GPIO, 0U);
						vTaskDelay(1000 / portTICK_RATE_MS);

						if (checkBuffEqual(uid, uidMaster, MAX_UID_LENGTH)) {
							serviceParameters.service_on = false;
							gpio_set_level(RELE_GPIO, 0U);
						}

					}

				}

			}
			else {

				for (request_str_index = 0; request_str_index < strlen(testPostRequest); request_str_index++) {
					request[request_str_index] = testPostRequest[request_str_index];
				}

				request[request_str_index] = '0';
				request[request_str_index + 1] = '0';
				request[request_str_index + 2] = '#';
				request[request_str_index + 3] = strHex[13];
				request[request_str_index + 4] = strHex[14];
				request[request_str_index + 5] = strHex[16];
				request[request_str_index + 6] = strHex[17];
				request[request_str_index + 7] = strHex[19];
				request[request_str_index + 8] = strHex[20];
				request[request_str_index + 9] = strHex[22];
				request[request_str_index + 10] = strHex[23];
				request[request_str_index + 11] = '\r';
				request[request_str_index + 12] = '\n';

				if (http_request(request, answer)) {
					printf("%s\n", answer);
					serviceParameters.service_time = string2uint(answer, 5U);
					printf("service time -> %llu\n", serviceParameters.service_time);

					if (serviceParameters.service_time != 0) {
						serviceParameters.service_on = true;
						gpio_set_level(RELE_GPIO, 1U);

						ssd1306_clear_screen(&dev, true);
						ssd1306_contrast(&dev, 0xff);
						ssd1306_display_text(&dev, 2, "       ON", 9, true);


						for (uint8_t i = 0; i < MAX_UID_LENGTH; i++) {
							uid_active[i] = uid[i];
						}

						while (serviceParameters.service_on) {
							clearBuff(uid);
							uid_length = nfc_task(uid, 500);

							if (uid_length != -1) {
								gpio_set_level(BUZZER_GPIO, 1U);
								vTaskDelay(1000 / portTICK_RATE_MS);
								gpio_set_level(BUZZER_GPIO, 0U);
								vTaskDelay(1000 / portTICK_RATE_MS);

								if (checkBuffEqual(uid_active, uid, MAX_UID_LENGTH) || checkBuffEqual(uid, uidMaster, MAX_UID_LENGTH)) {
									serviceParameters.service_on = false;
									gpio_set_level(RELE_GPIO, 0U);
								}

							}

							if (serviceParameters.service_time == 0) {
								serviceParameters.service_on = false;
								gpio_set_level(RELE_GPIO, 0U);
							}

						}

					}

				}
				else {
					ssd1306_clear_screen(&dev, false);
					ssd1306_contrast(&dev, 0xff);
					ssd1306_display_text(&dev, 2, "   COM ERROR", 12, false);
					esp_restart();
				}

			}

		}

	}

}

void app_main(void)
{
	xTaskCreate(&main_task, "main_task", 4096, NULL, 4, NULL);
	xTaskCreate(&blink_task, "blink_task", configMINIMAL_STACK_SIZE, NULL, 5, NULL);
}




