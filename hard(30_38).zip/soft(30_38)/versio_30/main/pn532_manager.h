/*
 * pn532_manager.h
 *
 *  Created on: 10 abr 2022
 *      Author: ferranbofill
 */

#ifndef MAIN_PN532_MANAGER_H_
#define MAIN_PN532_MANAGER_H_

#define MAX_UID_LENGTH 7

void pn532_init(void);
int8_t nfc_task(uint8_t* uid, uint16_t timeout);



#endif /* MAIN_PN532_MANAGER_H_ */
